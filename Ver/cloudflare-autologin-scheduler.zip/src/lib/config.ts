/**
 * ─── Central Configuration ──────────────────────────────────────────────
 * All env vars with sensible defaults. The app works even when .env only
 * has DATABASE_URL (platform-managed). Override any value in .env or via
 * Cloudflare Worker secrets.
 *
 * For production: set AUTH_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD as secrets.
 * For Cloudflare D1: leave DATABASE_URL empty.
 */

function getEnv(key: string, fallback = ""): string {
  const val = process.env[key];
  if (val === undefined || val === null) return fallback;
  return val.trim();
}

function getBool(key: string, fallback: boolean): boolean {
  const val = process.env[key];
  if (val === undefined || val === null) return fallback;
  return val.toLowerCase() === "true";
}

export const config = {
  // Database — PostgreSQL (set DATABASE_URL) OR Cloudflare D1 (leave empty)
  DATABASE_URL: getEnv("DATABASE_URL"),
  HAS_PG: Boolean(getEnv("DATABASE_URL")),

  // Auth secrets — fallback ensures dev works without .env setup
  AUTH_SECRET:
    getEnv("AUTH_SECRET") ||
    getEnv("JWT_SECRET") ||
    "autologin-fallback-dev-secret-change-in-production-2026",

  // Admin credentials — hardcoded defaults for instant login
  ADMIN_EMAIL: getEnv("ADMIN_EMAIL", "sudhi@gmal.com"),
  ADMIN_PASSWORD: getEnv("ADMIN_PASSWORD", "1Sudhi@gmal.com"),

  // Feature flags
  FAKE_DATA: process.env.FAKE_DATA !== "false", // default true
  ALLOW_REGISTRATION: process.env.ALLOW_REGISTRATION !== "false", // default true

  // Email providers (optional)
  RESEND_API_KEY: getEnv("RESEND_API_KEY"),
  RESEND_FROM: getEnv("RESEND_FROM"),
  BREVO_API_KEY: getEnv("BREVO_API_KEY"),
  BREVO_FROM: getEnv("BREVO_FROM"),
  SMTP_HOST: getEnv("SMTP_HOST"),
  SMTP_PORT: getEnv("SMTP_PORT", "587"),
  SMTP_USER: getEnv("SMTP_USER"),
  SMTP_PASS: getEnv("SMTP_PASS"),
  SMTP_FROM: getEnv("SMTP_FROM"),

  // S3 / R2 storage (optional)
  S3_ENDPOINT: getEnv("S3_ENDPOINT"),
  S3_ACCESS_KEY_ID: getEnv("S3_ACCESS_KEY_ID"),
  S3_SECRET_ACCESS_KEY: getEnv("S3_SECRET_ACCESS_KEY"),
  S3_BUCKET_NAME: getEnv("S3_BUCKET_NAME", "autologin-screenshots"),
  S3_REGION: getEnv("S3_REGION", "us-east-1"),

  // Derived helpers
  HAS_EMAIL:
    Boolean(getEnv("RESEND_API_KEY")) ||
    Boolean(getEnv("BREVO_API_KEY")) ||
    Boolean(getEnv("SMTP_HOST")),
  HAS_STORAGE:
    Boolean(getEnv("S3_ENDPOINT")) && Boolean(getEnv("S3_BUCKET_NAME")),
} as const;

export function isAdminEmail(email: string): boolean {
  return email.toLowerCase() === config.ADMIN_EMAIL.toLowerCase();
}
